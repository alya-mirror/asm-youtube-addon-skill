asm-youtube-lambdas-function
